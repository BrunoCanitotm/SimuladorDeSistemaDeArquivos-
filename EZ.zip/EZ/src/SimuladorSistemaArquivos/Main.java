package SimuladorSistemaArquivos;

public class Main {
    public static void main(String[] args) {
        Shell shell = new Shell();
        shell.iniciar();
    }
}